package com.example.clientorder.ObjectsAndAdapters;

public class Profil {

    public String id;
    public int points;



    public Profil() {
    }

    public Profil(String id, int points) {
        this.id = id;
        this.points = points;
    }






}

